// Gerado por ferramentas/gerarVersao.mjs a partir do package.json. Não edite à mão.
export const VERSAO_DO_APP = '3.6.0';
